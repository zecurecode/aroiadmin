<?php

include 'api.php';

sendSms(33644, 90039911);

?>